import 'package:flutter/material.dart';

// ─────────────────────────────────────────────────────────────
//  MODEL
// ─────────────────────────────────────────────────────────────

enum NotifType { offer, shop, order, wishlist, system }

class NotificationModel {
  final String id;
  final String title;
  final String subtitle;
  final String time;
  final NotifType type;
  bool isRead;

  NotificationModel({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.time,
    required this.type,
    this.isRead = false,
  });
}

// ─────────────────────────────────────────────────────────────
//  REPOSITORY — replace with real API
// ─────────────────────────────────────────────────────────────

class NotificationsRepository {
  // TODO: replace with GET /api/notifications
  static Future<List<NotificationModel>> fetchNotifications() async {
    await Future.delayed(const Duration(milliseconds: 400));
    return [
      NotificationModel(
        id: '1', type: NotifType.offer, isRead: false,
        title: '🏷️ Special Offer Just for You!',
        subtitle: 'Vogue Boutique is offering 30% off on all jackets today. Grab it before it\'s gone!',
        time: '2 min ago',
      ),
      NotificationModel(
        id: '2', type: NotifType.shop, isRead: false,
        title: '🏪 New Shop Nearby!',
        subtitle: 'Fashion Hub has opened 0.7 km from you. Check out 95+ new items!',
        time: '1 hr ago',
      ),
      NotificationModel(
        id: '3', type: NotifType.order, isRead: true,
        title: '📦 Order Ready for Pickup',
        subtitle: 'Your order #1023 from Urban Style is ready. Visit the shop to collect.',
        time: '3 hrs ago',
      ),
      NotificationModel(
        id: '4', type: NotifType.wishlist, isRead: true,
        title: '❤️ Wishlist Item Back in Stock',
        subtitle: 'Denim Jeans (₹1,250) you wishlisted at Lifestyle Attire is back in stock!',
        time: 'Yesterday',
      ),
      NotificationModel(
        id: '5', type: NotifType.offer, isRead: true,
        title: '🏷️ Weekend Sale Alert',
        subtitle: 'Urban Style is having a weekend sale — up to 50% off on selected items.',
        time: 'Yesterday',
      ),
      NotificationModel(
        id: '6', type: NotifType.system, isRead: true,
        title: '✅ Profile Updated Successfully',
        subtitle: 'Your Shopsyra profile has been updated. All changes are saved.',
        time: '2 days ago',
      ),
      NotificationModel(
        id: '7', type: NotifType.shop, isRead: true,
        title: '⭐ Rate Your Last Visit',
        subtitle: 'How was your experience at Vogue Boutique? Tap to leave a review.',
        time: '3 days ago',
      ),
    ];
  }

  // TODO: replace with PATCH /api/notifications/read-all
  static Future<void> markAllRead() async {
    await Future.delayed(const Duration(milliseconds: 300));
  }
}

// ─────────────────────────────────────────────────────────────
//  PAGE
// ─────────────────────────────────────────────────────────────

class NotificationsPage extends StatefulWidget {
  const NotificationsPage({super.key});
  @override
  State<NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> with SingleTickerProviderStateMixin {
  final Color primaryOrange = const Color(0xFFCC6B2C);
  final Color darkBrown     = const Color(0xFF2A1506);
  final Color bgColor       = const Color(0xFFF0E8DF);

  List<NotificationModel> _notifications = [];
  bool _loading = true;

  late AnimationController _fadeCtrl;
  late Animation<double>   _fadeAnim;

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(duration: const Duration(milliseconds: 600), vsync: this);
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeIn);
    _load();
  }

  Future<void> _load() async {
    final data = await NotificationsRepository.fetchNotifications();
    if (!mounted) return;
    setState(() { _notifications = data; _loading = false; });
    _fadeCtrl.forward();
  }

  Future<void> _markAllRead() async {
    await NotificationsRepository.markAllRead();
    setState(() {
      for (final n in _notifications) n.isRead = true;
    });
  }

  int get _unreadCount => _notifications.where((n) => !n.isRead).length;

  @override
  void dispose() {
    _fadeCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      body: Column(
        children: [
          _buildNavBar(context),
          Expanded(
            child: _loading
                ? Center(child: CircularProgressIndicator(color: primaryOrange, strokeWidth: 2.5))
                : FadeTransition(
                    opacity: _fadeAnim,
                    child: _notifications.isEmpty
                        ? _emptyState()
                        : RefreshIndicator(
                            color: primaryOrange,
                            onRefresh: () async {
                              setState(() => _loading = true);
                              _fadeCtrl.reset();
                              await _load();
                            },
                            child: ListView.builder(
                              physics: const BouncingScrollPhysics(),
                              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                              itemCount: _notifications.length,
                              itemBuilder: (ctx, i) => _notifCard(_notifications[i], i),
                            ),
                          ),
                  ),
          ),
        ],
      ),
    );
  }

  // ── NAV BAR ──
  Widget _buildNavBar(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: Container(
        color: bgColor,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 38, height: 38,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.07), blurRadius: 8)],
                ),
                child: Icon(Icons.arrow_back_ios_new_rounded, color: darkBrown, size: 16),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Notifications',
                      style: TextStyle(color: darkBrown, fontSize: 18, fontWeight: FontWeight.w800)),
                  if (_unreadCount > 0)
                    Text('$_unreadCount unread',
                        style: TextStyle(color: primaryOrange, fontSize: 12, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
            if (_unreadCount > 0)
              GestureDetector(
                onTap: _markAllRead,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                  decoration: BoxDecoration(
                    color: primaryOrange.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text('Mark all read',
                      style: TextStyle(color: primaryOrange, fontSize: 12, fontWeight: FontWeight.w700)),
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ── NOTIFICATION CARD ──
  Widget _notifCard(NotificationModel notif, int index) {
    Color iconBg;
    IconData iconData;

    switch (notif.type) {
      case NotifType.offer:
        iconBg = const Color(0xFFFFE8D6); iconData = Icons.local_offer_rounded; break;
      case NotifType.shop:
        iconBg = const Color(0xFFD6EAD6); iconData = Icons.store_rounded; break;
      case NotifType.order:
        iconBg = const Color(0xFFD6E4FF); iconData = Icons.shopping_bag_rounded; break;
      case NotifType.wishlist:
        iconBg = const Color(0xFFFFD6D6); iconData = Icons.favorite_rounded; break;
      case NotifType.system:
        iconBg = const Color(0xFFE8E8E8); iconData = Icons.info_rounded; break;
    }

    Color iconColor;
    switch (notif.type) {
      case NotifType.offer:    iconColor = primaryOrange; break;
      case NotifType.shop:     iconColor = Colors.green.shade600; break;
      case NotifType.order:    iconColor = Colors.blue.shade600; break;
      case NotifType.wishlist: iconColor = Colors.red.shade400; break;
      case NotifType.system:   iconColor = Colors.grey.shade600; break;
    }

    return GestureDetector(
      onTap: () => setState(() => notif.isRead = true),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: notif.isRead ? Colors.white : primaryOrange.withOpacity(0.06),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: notif.isRead ? Colors.transparent : primaryOrange.withOpacity(0.25),
            width: 1.2,
          ),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 3)),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Icon
              Container(
                width: 46, height: 46,
                decoration: BoxDecoration(color: iconBg, borderRadius: BorderRadius.circular(14)),
                child: Icon(iconData, color: iconColor, size: 22),
              ),
              const SizedBox(width: 12),

              // Content
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(notif.title,
                              style: TextStyle(
                                  color: darkBrown, fontSize: 13.5,
                                  fontWeight: notif.isRead ? FontWeight.w600 : FontWeight.w800),
                              maxLines: 1, overflow: TextOverflow.ellipsis),
                        ),
                        if (!notif.isRead)
                          Container(
                            width: 8, height: 8,
                            decoration: BoxDecoration(color: primaryOrange, shape: BoxShape.circle),
                          ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(notif.subtitle,
                        style: TextStyle(color: darkBrown.withOpacity(0.55), fontSize: 12.5, height: 1.4),
                        maxLines: 2, overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 6),
                    Text(notif.time,
                        style: TextStyle(color: darkBrown.withOpacity(0.35), fontSize: 11.5, fontWeight: FontWeight.w500)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── EMPTY STATE ──
  Widget _emptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 90, height: 90,
            decoration: BoxDecoration(color: primaryOrange.withOpacity(0.1), shape: BoxShape.circle),
            child: Icon(Icons.notifications_off_outlined, color: primaryOrange, size: 42),
          ),
          const SizedBox(height: 20),
          Text('No Notifications', style: TextStyle(color: darkBrown, fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text('You\'re all caught up!\nNew notifications will appear here.',
              textAlign: TextAlign.center,
              style: TextStyle(color: darkBrown.withOpacity(0.45), fontSize: 13.5, height: 1.5)),
        ],
      ),
    );
  }
}