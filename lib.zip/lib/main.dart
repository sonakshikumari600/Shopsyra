import 'package:flutter/material.dart';
import 'landing_page.dart';

void main() {
  runApp(const ShopsyraApp());
}

class ShopsyraApp extends StatelessWidget {
  const ShopsyraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Shopsyra',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Georgia',
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFD2691E),
        ),
        useMaterial3: true,
      ),
      home: LandingPage(),
    );
  }
}